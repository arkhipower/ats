
# ATS Optimizer Pro

AI-инструмент для генерации отраслевых ключевых слов (white keywords), даже если их нет в резюме. Использует Ollama и LLM-модель (например, LLaMA3) через `http://localhost:11434`.

## Запуск
```
python app/main.py
```

## Настройки
Файл промпта: `prompts/prompt_keywords.txt`
