
# CHANGELOG

## [v0.1.0] - Initial Release
- Added White Keyword Generator via Ollama
- Tkinter GUI: paste CV, industry, and generate keywords
- Basic prompts and modular AI integration
